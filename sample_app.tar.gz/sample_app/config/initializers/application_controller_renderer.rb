# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '84e47e262a259790ad2d2668fed7d0b5a59554ea41689141ab7127e9628dd45a36f61d28bb564bd006cdec6c60d40b446a2989cc1c9a1491ada77b864ffc21f8'