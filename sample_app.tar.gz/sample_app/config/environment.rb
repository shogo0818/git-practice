# Load the Rails application.
require_relative 'application'

#raInitialize the Rails application.
Rails.application.initialize!
